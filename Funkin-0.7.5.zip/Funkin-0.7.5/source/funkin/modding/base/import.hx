import polymod.hscript.HScriptedClass;
